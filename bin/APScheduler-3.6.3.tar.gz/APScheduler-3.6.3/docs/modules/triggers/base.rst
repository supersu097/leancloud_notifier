:mod:`apscheduler.triggers.base`
================================

.. automodule:: apscheduler.triggers.base

API
---

.. autoclass:: BaseTrigger
    :members:
